"""
schedule_greedy.py
===================
Жадный (эвристический) алгоритм составления расписания смен.

Вход: требуемое число окон по часам R_total/R_credit/R_mortgage(hour) —
результат required_windows.required_windows_table(). Выход: распределение
сотрудников отделения по сменам на один день (schedule_day) или на всю
рабочую неделю (schedule_week), с соблюдением:
    - иерархии навыков (mortgage-окна может закрыть только senior,
      credit-окна — middle и senior, total-окна — любой грейд);
    - обязательного обеденного перерыва в середине смены;
    - дневного (max_hours_day) и недельного (max_hours_week) лимита часов;
    - физического потолка окон отделения (n_windows_max) — жёсткое
      ограничение, нельзя поставить больше людей одновременно, чем есть
      окон, даже если формально штат позволяет.

Алгоритм (schedule_day) работает в 3 последовательных прохода — сначала
закрывает дефицит mortgage-окон (самый ограниченный ресурс — только
senior), затем credit (middle+), затем total (любой грейд). На каждом шаге
жадно выбирается пара (сотрудник, смена), которая закрывает наибольший
текущий дефицит; при равенстве предпочитается более дешёвый сотрудник.

Ограничение метода: жадный выбор не видит "вперёд" на весь день/неделю
целиком, поэтому может давать субоптимальный результат там, где важна
глобальная координация смен (см. schedule_ilp.py — точный ILP-солвер для
сравнения; schedule_ilp.py систематически превосходит жадный в сравнениях
compare_policies.py / compare_branches.py / week_pipeline.py).

Параметризован по branch_id/weekday -> тривиально масштабируется на другие
отделения и дни (см. schedule_week() в конце файла).
"""
import pandas as pd
import numpy as np
from dataclasses import dataclass, field
from typing import Optional
from required_windows import required_windows_table

SKILL_RANK = {'basic': 0, 'credit': 1, 'mortgage': 2}


@dataclass
class Pattern:
    """
    Один вариант смены: непрерывный блок часов [start, end) с опциональным
    часом обеда где-то в середине (обед исключается из serving_hours — в
    этот час сотрудник не обслуживает окно).

    Attributes:
        start: час начала смены.
        end: час окончания смены (открытый интервал — сам час end уже не
            входит в смену).
        lunch_hour: час обеда (не входит в serving_hours), либо None для
            коротких смен без обязательного обеда.
        serving_hours: кортеж часов, когда сотрудник реально обслуживает
            окно (span минус час обеда, если он есть).
    """
    start: int
    end: int                      # открытый интервал [start, end)
    lunch_hour: Optional[int]     # час обеда (исключается из serving_hours), None если смена короткая
    serving_hours: tuple          # часы, в которые сотрудник реально обслуживает окно

    @property
    def span(self):
        """Полная длительность смены в часах, включая обед (start до end)."""
        return self.end - self.start

    @property
    def paid_hours(self):
        """Число фактически рабочих (оплачиваемых, обслуживающих) часов — без обеда."""
        return len(self.serving_hours)


def generate_patterns(open_hour: int, close_hour: int, max_span: int = 9,
                       min_span: int = 2, lunch_required_from_span: int = 6):
    """
    Генерирует все допустимые варианты смен для отделения, открытого в
    [open_hour, close_hour).

    Для каждого возможного часа начала и каждой длины смены (от min_span до
    max_span часов) строится Pattern. Если длина смены >= lunch_required_from_span,
    перебираются все допустимые позиции обеда (минимум 2 рабочих часа до
    обеда и 1 час после — не даём обеду стоять впритык к краю смены).
    Короткие смены (< lunch_required_from_span часов) обеда не имеют —
    предполагается, что по трудовому распорядку он не обязателен для
    коротких "смен-затычек", которыми жадный алгоритм закрывает точечные
    пики на границах дня (см. docstring schedule_day).

    Разные позиции обеда при одинаковых (start, end) — это РАЗНЫЕ паттерны:
    они по-разному покрывают часы дня, и это осознанно даёт жадному
    алгоритму больше гибкости при выборе.

    Args:
        open_hour: час открытия отделения.
        close_hour: час закрытия отделения (сам этот час уже не входит в
            рабочий день — например, close_hour=19 означает "до 19:00").
        max_span: максимальная длина смены в часах (обычно = max_hours_day
            сотрудника, включая обед).
        min_span: минимальная длина смены в часах (короткие смены нужны,
            чтобы закрывать точечные пики без переполнения соседних часов —
            см. пример в README/отчёте про час открытия BR01).
        lunch_required_from_span: с какой длины смены обед обязателен.

    Returns:
        Список уникальных объектов Pattern (дубли по (start, end, lunch_hour)
        убраны).
    """
    patterns = []
    for start in range(open_hour, close_hour):
        for span in range(min_span, max_span + 1):
            end = start + span
            if end > close_hour:
                continue
            if span >= lunch_required_from_span:
                # обед где-то в средней части смены, минимум 2ч работы до и 1ч после
                for lunch_hour in range(start + 2, end - 1):
                    serving = tuple(h for h in range(start, end) if h != lunch_hour)
                    patterns.append(Pattern(start, end, lunch_hour, serving))
            else:
                patterns.append(Pattern(start, end, None, tuple(range(start, end))))
    # убрать дубли по (start,end,lunch_hour) — на случай, если генерация выше
    # случайно создала одинаковые паттерны
    seen = set()
    uniq = []
    for p in patterns:
        key = (p.start, p.end, p.lunch_hour)
        if key not in seen:
            seen.add(key)
            uniq.append(p)
    return uniq


def schedule_day(employees: pd.DataFrame, req: pd.DataFrame, open_hour: int, close_hour: int,
                  n_windows_max: int, weekly_hours_used: dict = None,
                  max_hours_week: int = 40, max_hours_day: int = 9):
    """
    Жадный алгоритм: распределяет сотрудников ОДНОГО отделения по сменам на
    ОДИН день, чтобы максимально закрыть требуемое число окон R_total/
    R_credit/R_mortgage по часам.

    Алгоритм в 3 прохода (по убыванию "дефицитности" ресурса):
        1. tier='mortgage' — закрываем дефицит окон, требующих senior;
        2. tier='credit'   — закрываем дефицит окон, требующих middle+;
        3. tier='total'    — закрываем оставшийся дефицит любым грейдом.
    Внутри каждого прохода — цикл "пока есть незакрытый дефицит для этого
    tier": находим час t_star с максимальным дефицитом, перебираем всех ещё
    не занятых сегодня сотрудников подходящей квалификации и все паттерны
    смен, включающие t_star, и жадно выбираем пару (сотрудник, паттерн),
    которая закрывает больше всего суммарного дефицита (по всем trём tier
    сразу — см. расчёт score), при равенстве — более дешёвого сотрудника.

    Физический потолок окон (n_windows_max) соблюдается как жёсткое
    ограничение на каждом шаге: паттерн отбрасывается, если хотя бы в один
    из его часов уже работает n_windows_max человек — иначе это означало бы
    более людей одновременно, чем есть окон, что физически невозможно.

    Если для какого-то часа не находится подходящего сотрудника/паттерна
    (например, все нужной квалификации уже заняты или их часы исчерпаны),
    дефицит на этом (tier, час) заносится в given_up — чтобы не зациклиться
    — но НЕ исправляет R_total/R_credit/R_mortgage, поэтому итоговый
    coverage_df честно показывает реальную нехватку (см. unresolved).

    Args:
        employees: датафрейм сотрудников ОДНОГО отделения со столбцами
            employee_id, grade, skills (list), hourly_cost_rub, и опционально
            name. Обычно — уже отфильтрованный по branch_id срез employees.csv.
        req: датафрейм из required_windows_table (столбцы hour, R_total,
            R_credit, R_mortgage) для этого отделения/дня недели.
        open_hour: час открытия отделения.
        close_hour: час закрытия отделения.
        n_windows_max: физическое число окон отделения (branches.csv).
        weekly_hours_used: {employee_id: часов уже отработано на этой
            неделе} — для многодневного режима (перенос между днями через
            schedule_week). По умолчанию все сотрудники считаются "с нуля".
        max_hours_week: недельный лимит часов на сотрудника (трудовое
            ограничение).
        max_hours_day: (не используется напрямую здесь — лимит на длину
            смены уже заложен в generate_patterns через max_span; параметр
            оставлен для единообразия сигнатуры с schedule_ilp).

    Returns:
        Кортеж (assignments, coverage_df, unresolved, weekly_hours_used):
        - assignments: список dict — по одному на назначенную смену
          (employee_id, grade, start, end, lunch_hour, serving_hours,
          paid_hours, hourly_cost, shift_cost);
        - coverage_df: DataFrame по часам — R_total/cov_total, R_credit/
          cov_credit, R_mortgage/cov_mortgage (требуется vs фактически
          закрыто);
        - unresolved: список текстовых предупреждений о часах, где дефицит
          закрыть не удалось (реальная нехватка ресурса, а не баг);
        - weekly_hours_used: обновлённый словарь отработанных часов (для
          передачи в schedule_day следующего дня при многодневном режиме).
    """
    weekly_hours_used = dict(weekly_hours_used or {})
    hours = list(req['hour'])
    R_total = dict(zip(req['hour'], req['R_total']))
    R_credit = dict(zip(req['hour'], req['R_credit']))
    R_mortgage = dict(zip(req['hour'], req['R_mortgage']))

    cov_total = {h: 0 for h in hours}
    cov_credit = {h: 0 for h in hours}
    cov_mortgage = {h: 0 for h in hours}

    patterns = generate_patterns(open_hour, close_hour)
    assigned_today = set()  # employee_id уже получивших смену сегодня (максимум 1 смена/день)
    assignments = []
    unresolved = []

    def eligible(emp_skills, tier):
        """Может ли сотрудник с данным набором навыков закрывать окно уровня tier."""
        if tier == 'mortgage':
            return 'mortgage' in emp_skills
        if tier == 'credit':
            return 'credit' in emp_skills or 'mortgage' in emp_skills
        return True  # total tier — любой грейд подходит

    given_up = set()  # (tier, hour) — признанные нерешаемыми, чтобы не зацикливаться; R_* при этом не портим

    def deficit(tier, h):
        """Текущий незакрытый дефицит окон уровня tier в час h (0, если уже закрыт или given_up)."""
        if (tier, h) in given_up:
            return 0
        if tier == 'mortgage':
            return max(0, R_mortgage[h] - cov_mortgage[h])
        if tier == 'credit':
            return max(0, R_credit[h] - cov_credit[h])
        return max(0, R_total[h] - cov_total[h])

    for tier in ['mortgage', 'credit', 'total']:
        while True:
            deficits = {h: deficit(tier, h) for h in hours}
            if max(deficits.values(), default=0) == 0:
                break
            # час с максимальным дефицитом (при равенстве — самый ранний по номеру часа)
            t_star = max(hours, key=lambda h: (deficits[h], -h))
            if deficits[t_star] == 0:
                break

            # кандидаты: ещё не работающие сегодня сотрудники нужной квалификации
            candidates = employees[~employees['employee_id'].isin(assigned_today)].copy()
            candidates = candidates[candidates['skills'].apply(lambda s: eligible(s, tier))]

            best = None  # (score, -cost, -paid_hours), выбираем максимум по этому ключу
            for _, e in candidates.iterrows():
                remaining_week = max_hours_week - weekly_hours_used.get(e['employee_id'], 0)
                if remaining_week <= 0:
                    continue
                for p in patterns:
                    if t_star not in p.serving_hours:
                        continue  # паттерн не покрывает интересующий нас час — не годится
                    if p.paid_hours > remaining_week:
                        continue  # не хватает оставшихся недельных часов на эту смену
                    # физический потолок: нельзя занять окно, если все n_windows_max уже заняты в этот час
                    if any(cov_total[h] >= n_windows_max for h in p.serving_hours):
                        continue
                    # сколько текущих дефицитов (по всем trём уровням сразу) закроет эта смена —
                    # total считается всегда, credit/mortgage — только если сотрудник этой квалификации
                    # (вес 0.5, чтобы total-дефицит был первичным приоритетом, а skill-дефицит — бонусом)
                    score = 0.0
                    for h in p.serving_hours:
                        score += deficit('total', h) * 1.0
                        score += deficit('credit', h) * 0.5 if eligible(e['skills'], 'credit') else 0
                        score += deficit('mortgage', h) * 0.5 if eligible(e['skills'], 'mortgage') else 0
                    # при равном score предпочитаем более дешёвого сотрудника (-cost),
                    # затем более короткую смену (-paid_hours, экономия часов на будущее)
                    key = (score, -e['hourly_cost_rub'], -p.paid_hours)
                    if best is None or key > best[0]:
                        best = (key, p, e)

            if best is None:
                # ни один доступный сотрудник/паттерн не может закрыть этот дефицит —
                # реальная нехватка ресурса (квалификации, часов) или столкновение с
                # потолком окон в соседний час смены
                unresolved.append(f"Час {t_star}: не нашлось сотрудника/смены, чтобы закрыть дефицит "
                                   f"({tier}, дефицит={deficits[t_star]}) — не хватает людей нужной квалификации/часов "
                                   f"или это столкнётся с лимитом окон в соседние часы смены")
                given_up.add((tier, t_star))  # не зацикливаемся, но R_total/R_credit/R_mortgage остаются как есть
                continue

            _, p, e = best
            assigned_today.add(e['employee_id'])
            weekly_hours_used[e['employee_id']] = weekly_hours_used.get(e['employee_id'], 0) + p.paid_hours
            for h in p.serving_hours:
                cov_total[h] += 1
                if eligible(e['skills'], 'credit'):
                    cov_credit[h] += 1
                if eligible(e['skills'], 'mortgage'):
                    cov_mortgage[h] += 1
            assignments.append(dict(employee_id=e['employee_id'], name=e.get('name', ''), grade=e['grade'],
                                     start=p.start, end=p.end, lunch_hour=p.lunch_hour,
                                     serving_hours=p.serving_hours, paid_hours=p.paid_hours,
                                     hourly_cost=e['hourly_cost_rub'], shift_cost=p.paid_hours * e['hourly_cost_rub']))

    coverage_df = pd.DataFrame({
        'hour': hours,
        'R_total': [R_total[h] for h in hours], 'cov_total': [cov_total[h] for h in hours],
        'R_credit': [R_credit[h] for h in hours], 'cov_credit': [cov_credit[h] for h in hours],
        'R_mortgage': [R_mortgage[h] for h in hours], 'cov_mortgage': [cov_mortgage[h] for h in hours],
    })
    return assignments, coverage_df, unresolved, weekly_hours_used


WEEKDAY_HOURS = {  # (open_hour, close_hour) — из branches.csv: будни 09-19, суббота 09-16, воскресенье закрыто
    'Monday': (9, 19), 'Tuesday': (9, 19), 'Wednesday': (9, 19),
    'Thursday': (9, 19), 'Friday': (9, 19), 'Saturday': (9, 16),
}


def schedule_week(client_arrivals: pd.DataFrame, operations: pd.DataFrame, employees: pd.DataFrame,
                   branches: pd.DataFrame, branch_id: str):
    """
    Масштабирует schedule_day на всю рабочую неделю (Пн-Сб) одного отделения.

    Вызывает schedule_day() по очереди для каждого дня недели, передавая
    weekly_hours_used из предыдущего дня в следующий — так недельный лимит
    в 40 часов соблюдается СКВОЗНО по всей неделе, а не независимо в каждом
    дне (иначе жадный алгоритм мог бы "нечестно" использовать одного и того
    же сотрудника на полную ставку каждый день).

    Args:
        client_arrivals: датафрейм client_arrivals.csv (или эквивалент).
        operations: датафрейм operations.csv.
        employees: полный датафрейм сотрудников (employees.csv, все
            отделения — фильтрация по branch_id происходит внутри).
        branches: датафрейм branches.csv, индексированный по branch_id
            (branches.set_index('branch_id')).
        branch_id: идентификатор отделения, для которого строим расписание.

    Returns:
        Кортеж (results, summary):
        - results: dict{weekday: {'assignments':…, 'coverage':…,
          'unresolved':…}} — по одному ключу на каждый рабочий день недели;
        - summary: DataFrame по сотрудникам с итоговой недельной загрузкой
          (hours_this_week, max_hours_week, utilization) — удобно для
          проверки, кто из сотрудников "выгорел" к концу недели (utilization
          близко к 1.0).
    """
    n_win = int(branches.loc[branch_id, 'n_windows'])
    branch_emp = employees[employees['branch_id'] == branch_id]
    weekly_hours_used = {}
    results = {}
    for weekday, (open_h, close_h) in WEEKDAY_HOURS.items():
        req = required_windows_table(client_arrivals, operations, branch_id, weekday, n_win)
        if req.empty:
            continue
        assignments, coverage, unresolved, weekly_hours_used = schedule_day(
            branch_emp, req, open_h, close_h, n_windows_max=n_win,
            weekly_hours_used=weekly_hours_used)  # <- перенос часов между днями недели
        results[weekday] = dict(assignments=assignments, coverage=coverage, unresolved=unresolved)

    summary = pd.DataFrame([
        dict(employee_id=eid, hours_this_week=h, max_hours_week=40, utilization=round(h/40, 2))
        for eid, h in weekly_hours_used.items()
    ]).sort_values('hours_this_week', ascending=False)
    return results, summary


if __name__ == '__main__':
    ca = pd.read_csv('dataset/client_arrivals.csv')
    ops = pd.read_csv('dataset/operations.csv')
    br = pd.read_csv('dataset/branches.csv').set_index('branch_id')
    emp = pd.read_csv('dataset/employees.csv')
    emp['skills'] = emp['skills'].str.split(',')

    BRANCH, WEEKDAY_EN = 'BR01', 'Monday'
    n_win = int(br.loc[BRANCH, 'n_windows'])
    open_h, close_h = 9, 19  # из hours_weekday «09:00-19:00»

    req = required_windows_table(ca, ops, BRANCH, WEEKDAY_EN, n_win)
    branch_emp = emp[emp['branch_id'] == BRANCH]

    assignments, coverage, unresolved, hours_used = schedule_day(
        branch_emp, req, open_h, close_h, n_windows_max=n_win)

    print(f"=== Расписание {BRANCH}, понедельник ===\n")
    sched_df = pd.DataFrame(assignments)
    print(sched_df[['employee_id', 'grade', 'start', 'end', 'lunch_hour', 'paid_hours', 'shift_cost']]
          .sort_values('start').to_string(index=False))

    print(f"\nСотрудников задействовано: {len(assignments)} из {len(branch_emp)}")
    print(f"Суммарный ФОТ за день: {sched_df['shift_cost'].sum():.0f} руб.")

    print("\n=== Покрытие по часам (требуется / открыто) ===")
    print(coverage.to_string(index=False))

    if unresolved:
        print("\n=== Нерешённые дефициты ===")
        for u in unresolved:
            print(" -", u)
    else:
        print("\nВсе требования по окнам закрыты штатом отделения.")
